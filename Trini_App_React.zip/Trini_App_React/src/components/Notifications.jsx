import { Toaster } from "sonner";

function Notifications() {
    return <Toaster position='top-right'  visibleToasts={9} closeButton />

}
export default Notifications