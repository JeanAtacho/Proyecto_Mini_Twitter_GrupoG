function HeaderProfile() {
    return <header className="headerProfile">
        <div className="headerProfile">
            <img className="profile_pictureUser" src="src/image/trini_purple.png" alt="" />
            <h2 className="userTrini">@Usuario_Trini</h2>
            <h3 className="nameTrini">Nombre_Apellido</h3>

        </div>
    </header>
}
export default HeaderProfile
