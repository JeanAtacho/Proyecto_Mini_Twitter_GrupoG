function Creditos() {
    return <p className="creditsTrini"> @2023 - Trini, Inc. <br /> Developed by: Jean | Marie | Olha. <br /> Program: &#123; Powercoders &#125; - Hack a boss.</p>
}

export default Creditos