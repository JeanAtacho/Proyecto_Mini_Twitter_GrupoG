import React from "react";
import Html from "../components/html";
import Navbar from "../components/Navbar";


function Main () {
    
    return (
        <>
           <Navbar />
        </>
    )
}

export default Main