const apiURL = 'https://minitwitter.backends.hackaboss.com'

export {
  apiURL
}